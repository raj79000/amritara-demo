(()=>{var e={};e.id=920,e.ids=[920],e.modules={440:(e,t,s)=>{"use strict";s.r(t),s.d(t,{default:()=>a});var r=s(1658);let a=async e=>[{type:"image/x-icon",sizes:"16x16",url:(0,r.fillMetadataSegment)(".",await e.params,"favicon.ico")+""}]},846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},1733:(e,t,s)=>{Promise.resolve().then(s.t.bind(s,5814,23)),Promise.resolve().then(s.t.bind(s,6533,23)),Promise.resolve().then(s.bind(s,8813)),Promise.resolve().then(s.bind(s,8360))},2655:(e,t,s)=>{"use strict";s.d(t,{default:()=>r});let r=(0,s(2907).registerClientReference)(function(){throw Error("Attempted to call the default export of \"C:\\\\cin-next\\\\amritara-demo\\\\src\\\\app\\\\Components\\\\ContactUsMain.js\" from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"C:\\cin-next\\amritara-demo\\src\\app\\Components\\ContactUsMain.js","default")},3033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},3702:(e,t,s)=>{"use strict";s.d(t,{A:()=>r});let r=(0,s(6373).A)("chevron-right",[["path",{d:"m9 18 6-6-6-6",key:"mthhwq"}]])},3873:e=>{"use strict";e.exports=require("path")},4031:(e,t,s)=>{"use strict";s.r(t),s.d(t,{default:()=>r});let r=(0,s(2907).registerClientReference)(function(){throw Error("Attempted to call the default export of \"C:\\\\cin-next\\\\amritara-demo\\\\src\\\\app\\\\Common\\\\MainHeader.js\" from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"C:\\cin-next\\amritara-demo\\src\\app\\Common\\MainHeader.js","default")},5285:(e,t,s)=>{Promise.resolve().then(s.t.bind(s,4536,23)),Promise.resolve().then(s.t.bind(s,9603,23)),Promise.resolve().then(s.bind(s,4031)),Promise.resolve().then(s.bind(s,2655))},5913:(e,t,s)=>{"use strict";s(6397);var r=s(3210),a=function(e){return e&&"object"==typeof e&&"default"in e?e:{default:e}}(r),i="undefined"!=typeof process&&process.env&&!0,c=function(e){return"[object String]"===Object.prototype.toString.call(e)},n=function(){function e(e){var t=void 0===e?{}:e,s=t.name,r=void 0===s?"stylesheet":s,a=t.optimizeForSpeed,n=void 0===a?i:a;o(c(r),"`name` must be a string"),this._name=r,this._deletedRulePlaceholder="#"+r+"-deleted-rule____{}",o("boolean"==typeof n,"`optimizeForSpeed` must be a boolean"),this._optimizeForSpeed=n,this._serverSheet=void 0,this._tags=[],this._injected=!1,this._rulesCount=0,this._nonce=null}var t,s=e.prototype;return s.setOptimizeForSpeed=function(e){o("boolean"==typeof e,"`setOptimizeForSpeed` accepts a boolean"),o(0===this._rulesCount,"optimizeForSpeed cannot be when rules have already been inserted"),this.flush(),this._optimizeForSpeed=e,this.inject()},s.isOptimizeForSpeed=function(){return this._optimizeForSpeed},s.inject=function(){var e=this;o(!this._injected,"sheet already injected"),this._injected=!0,this._serverSheet={cssRules:[],insertRule:function(t,s){return"number"==typeof s?e._serverSheet.cssRules[s]={cssText:t}:e._serverSheet.cssRules.push({cssText:t}),s},deleteRule:function(t){e._serverSheet.cssRules[t]=null}}},s.getSheetForTag=function(e){if(e.sheet)return e.sheet;for(var t=0;t<document.styleSheets.length;t++)if(document.styleSheets[t].ownerNode===e)return document.styleSheets[t]},s.getSheet=function(){return this.getSheetForTag(this._tags[this._tags.length-1])},s.insertRule=function(e,t){return o(c(e),"`insertRule` accepts only strings"),"number"!=typeof t&&(t=this._serverSheet.cssRules.length),this._serverSheet.insertRule(e,t),this._rulesCount++},s.replaceRule=function(e,t){this._optimizeForSpeed;var s=this._serverSheet;if(t.trim()||(t=this._deletedRulePlaceholder),!s.cssRules[e])return e;s.deleteRule(e);try{s.insertRule(t,e)}catch(r){i||console.warn("StyleSheet: illegal rule: \n\n"+t+"\n\nSee https://stackoverflow.com/q/20007992 for more info"),s.insertRule(this._deletedRulePlaceholder,e)}return e},s.deleteRule=function(e){this._serverSheet.deleteRule(e)},s.flush=function(){this._injected=!1,this._rulesCount=0,this._serverSheet.cssRules=[]},s.cssRules=function(){return this._serverSheet.cssRules},s.makeStyleTag=function(e,t,s){t&&o(c(t),"makeStyleTag accepts only strings as second parameter");var r=document.createElement("style");this._nonce&&r.setAttribute("nonce",this._nonce),r.type="text/css",r.setAttribute("data-"+e,""),t&&r.appendChild(document.createTextNode(t));var a=document.head||document.getElementsByTagName("head")[0];return s?a.insertBefore(r,s):a.appendChild(r),r},t=[{key:"length",get:function(){return this._rulesCount}}],function(e,t){for(var s=0;s<t.length;s++){var r=t[s];r.enumerable=r.enumerable||!1,r.configurable=!0,"value"in r&&(r.writable=!0),Object.defineProperty(e,r.key,r)}}(e.prototype,t),e}();function o(e,t){if(!e)throw Error("StyleSheet: "+t+".")}var l=function(e){for(var t=5381,s=e.length;s;)t=33*t^e.charCodeAt(--s);return t>>>0},d={};function m(e,t){if(!t)return"jsx-"+e;var s=String(t),r=e+s;return d[r]||(d[r]="jsx-"+l(e+"-"+s)),d[r]}function u(e,t){var s=e+(t=t.replace(/\/style/gi,"\\/style"));return d[s]||(d[s]=t.replace(/__jsx-style-dynamic-selector/g,e)),d[s]}var h=function(){function e(e){var t=void 0===e?{}:e,s=t.styleSheet,r=void 0===s?null:s,a=t.optimizeForSpeed,i=void 0!==a&&a;this._sheet=r||new n({name:"styled-jsx",optimizeForSpeed:i}),this._sheet.inject(),r&&"boolean"==typeof i&&(this._sheet.setOptimizeForSpeed(i),this._optimizeForSpeed=this._sheet.isOptimizeForSpeed()),this._fromServer=void 0,this._indices={},this._instancesCounts={}}var t=e.prototype;return t.add=function(e){var t=this;void 0===this._optimizeForSpeed&&(this._optimizeForSpeed=Array.isArray(e.children),this._sheet.setOptimizeForSpeed(this._optimizeForSpeed),this._optimizeForSpeed=this._sheet.isOptimizeForSpeed());var s=this.getIdAndRules(e),r=s.styleId,a=s.rules;if(r in this._instancesCounts){this._instancesCounts[r]+=1;return}var i=a.map(function(e){return t._sheet.insertRule(e)}).filter(function(e){return -1!==e});this._indices[r]=i,this._instancesCounts[r]=1},t.remove=function(e){var t=this,s=this.getIdAndRules(e).styleId;if(function(e,t){if(!e)throw Error("StyleSheetRegistry: "+t+".")}(s in this._instancesCounts,"styleId: `"+s+"` not found"),this._instancesCounts[s]-=1,this._instancesCounts[s]<1){var r=this._fromServer&&this._fromServer[s];r?(r.parentNode.removeChild(r),delete this._fromServer[s]):(this._indices[s].forEach(function(e){return t._sheet.deleteRule(e)}),delete this._indices[s]),delete this._instancesCounts[s]}},t.update=function(e,t){this.add(t),this.remove(e)},t.flush=function(){this._sheet.flush(),this._sheet.inject(),this._fromServer=void 0,this._indices={},this._instancesCounts={}},t.cssRules=function(){var e=this,t=this._fromServer?Object.keys(this._fromServer).map(function(t){return[t,e._fromServer[t]]}):[],s=this._sheet.cssRules();return t.concat(Object.keys(this._indices).map(function(t){return[t,e._indices[t].map(function(e){return s[e].cssText}).join(e._optimizeForSpeed?"":"\n")]}).filter(function(e){return!!e[1]}))},t.styles=function(e){var t,s;return t=this.cssRules(),void 0===(s=e)&&(s={}),t.map(function(e){var t=e[0],r=e[1];return a.default.createElement("style",{id:"__"+t,key:"__"+t,nonce:s.nonce?s.nonce:void 0,dangerouslySetInnerHTML:{__html:r}})})},t.getIdAndRules=function(e){var t=e.children,s=e.dynamic,r=e.id;if(s){var a=m(r,s);return{styleId:a,rules:Array.isArray(t)?t.map(function(e){return u(a,e)}):[u(a,t)]}}return{styleId:m(r),rules:Array.isArray(t)?t:[t]}},t.selectFromServer=function(){return Array.prototype.slice.call(document.querySelectorAll('[id^="__jsx-"]')).reduce(function(e,t){return e[t.id.slice(2)]=t,e},{})},e}(),p=r.createContext(null);p.displayName="StyleSheetContext";a.default.useInsertionEffect||a.default.useLayoutEffect;var b=void 0;function f(e){var t=b||r.useContext(p);return t&&t.add(e),null}f.dynamic=function(e){return e.map(function(e){return m(e[0],e[1])}).join(" ")},t.style=f},6022:()=>{},6180:(e,t,s)=>{"use strict";e.exports=s(5913).style},6397:()=>{},6407:()=>{},7152:(e,t,s)=>{"use strict";s.r(t),s.d(t,{GlobalError:()=>c.a,__next_app__:()=>m,pages:()=>d,routeModule:()=>u,tree:()=>l});var r=s(5239),a=s(8088),i=s(8170),c=s.n(i),n=s(893),o={};for(let e in n)0>["default","tree","pages","GlobalError","__next_app__","routeModule"].indexOf(e)&&(o[e]=()=>n[e]);s.d(t,o);let l={children:["",{children:["contact-us",{children:["__PAGE__",{},{page:[()=>Promise.resolve().then(s.bind(s,8550)),"C:\\cin-next\\amritara-demo\\src\\app\\contact-us\\page.js"]}]},{metadata:{icon:[async e=>(await Promise.resolve().then(s.bind(s,440))).default(e)],apple:[],openGraph:[],twitter:[],manifest:void 0}}]},{layout:[()=>Promise.resolve().then(s.bind(s,9219)),"C:\\cin-next\\amritara-demo\\src\\app\\layout.js"],"not-found":[()=>Promise.resolve().then(s.t.bind(s,7398,23)),"next/dist/client/components/not-found-error"],forbidden:[()=>Promise.resolve().then(s.t.bind(s,9999,23)),"next/dist/client/components/forbidden-error"],unauthorized:[()=>Promise.resolve().then(s.t.bind(s,5284,23)),"next/dist/client/components/unauthorized-error"],metadata:{icon:[async e=>(await Promise.resolve().then(s.bind(s,440))).default(e)],apple:[],openGraph:[],twitter:[],manifest:void 0}}]}.children,d=["C:\\cin-next\\amritara-demo\\src\\app\\contact-us\\page.js"],m={require:s,loadChunk:()=>Promise.resolve()},u=new r.AppPageRouteModule({definition:{kind:a.RouteKind.APP_PAGE,page:"/contact-us/page",pathname:"/contact-us",bundlePath:"",filename:"",appPaths:[]},userland:{loaderTree:l}})},8360:(e,t,s)=>{"use strict";s.d(t,{default:()=>ea});var r,a=s(687),i=s(6180),c=s.n(i),n=s(2688);let o=(0,n.A)("map-pinned",[["path",{d:"M18 8c0 3.613-3.869 7.429-5.393 8.795a1 1 0 0 1-1.214 0C9.87 15.429 6 11.613 6 8a6 6 0 0 1 12 0",key:"11u0oz"}],["circle",{cx:"12",cy:"8",r:"2",key:"1822b1"}],["path",{d:"M8.714 14h-3.71a1 1 0 0 0-.948.683l-2.004 6A1 1 0 0 0 3 22h18a1 1 0 0 0 .948-1.316l-2-6a1 1 0 0 0-.949-.684h-3.712",key:"q8zwxj"}]]),l=(0,n.A)("phone-call",[["path",{d:"M13 2a9 9 0 0 1 9 9",key:"1itnx2"}],["path",{d:"M13 6a5 5 0 0 1 5 5",key:"11nki7"}],["path",{d:"M13.832 16.568a1 1 0 0 0 1.213-.303l.355-.465A2 2 0 0 1 17 15h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2A18 18 0 0 1 2 4a2 2 0 0 1 2-2h3a2 2 0 0 1 2 2v3a2 2 0 0 1-.8 1.6l-.468.351a1 1 0 0 0-.292 1.233 14 14 0 0 0 6.392 6.384",key:"9njp5v"}]]),d=(0,n.A)("mail",[["path",{d:"m22 7-8.991 5.727a2 2 0 0 1-2.009 0L2 7",key:"132q7q"}],["rect",{x:"2",y:"4",width:"20",height:"16",rx:"2",key:"izxlao"}]]);var m=s(5814),u=s.n(m),h=s(3210);let p={data:""},b=e=>"object"==typeof window?((e?e.querySelector("#_goober"):window._goober)||Object.assign((e||document.head).appendChild(document.createElement("style")),{innerHTML:" ",id:"_goober"})).firstChild:e||p,f=/(?:([\u0080-\uFFFF\w-%@]+) *:? *([^{;]+?);|([^;}{]*?) *{)|(}\s*)/g,x=/\/\*[^]*?\*\/|  +/g,v=/\n+/g,g=(e,t)=>{let s="",r="",a="";for(let i in e){let c=e[i];"@"==i[0]?"i"==i[1]?s=i+" "+c+";":r+="f"==i[1]?g(c,i):i+"{"+g(c,"k"==i[1]?"":t)+"}":"object"==typeof c?r+=g(c,t?t.replace(/([^,])+/g,e=>i.replace(/([^,]*:\S+\([^)]*\))|([^,])+/g,t=>/&/.test(t)?t.replace(/&/g,e):e?e+" "+t:t)):i):null!=c&&(i=/^--/.test(i)?i:i.replace(/[A-Z]/g,"-$&").toLowerCase(),a+=g.p?g.p(i,c):i+":"+c+";")}return s+(t&&a?t+"{"+a+"}":a)+r},y={},_=e=>{if("object"==typeof e){let t="";for(let s in e)t+=s+_(e[s]);return t}return e},w=(e,t,s,r,a)=>{let i=_(e),c=y[i]||(y[i]=(e=>{let t=0,s=11;for(;t<e.length;)s=101*s+e.charCodeAt(t++)>>>0;return"go"+s})(i));if(!y[c]){let t=i!==e?e:(e=>{let t,s,r=[{}];for(;t=f.exec(e.replace(x,""));)t[4]?r.shift():t[3]?(s=t[3].replace(v," ").trim(),r.unshift(r[0][s]=r[0][s]||{})):r[0][t[1]]=t[2].replace(v," ").trim();return r[0]})(e);y[c]=g(a?{["@keyframes "+c]:t}:t,s?"":"."+c)}let n=s&&y.g?y.g:null;return s&&(y.g=y[c]),((e,t,s,r)=>{r?t.data=t.data.replace(r,e):-1===t.data.indexOf(e)&&(t.data=s?e+t.data:t.data+e)})(y[c],t,r,n),c},N=(e,t,s)=>e.reduce((e,r,a)=>{let i=t[a];if(i&&i.call){let e=i(s),t=e&&e.props&&e.props.className||/^go/.test(e)&&e;i=t?"."+t:e&&"object"==typeof e?e.props?"":g(e,""):!1===e?"":e}return e+r+(null==i?"":i)},"");function S(e){let t=this||{},s=e.call?e(t.p):e;return w(s.unshift?s.raw?N(s,[].slice.call(arguments,1),t.p):s.reduce((e,s)=>Object.assign(e,s&&s.call?s(t.p):s),{}):s,b(t.target),t.g,t.o,t.k)}S.bind({g:1});let C,k,A,z=S.bind({k:1});function P(e,t){let s=this||{};return function(){let r=arguments;function a(i,c){let n=Object.assign({},i),o=n.className||a.className;s.p=Object.assign({theme:k&&k()},n),s.o=/ *go\d+/.test(o),n.className=S.apply(s,r)+(o?" "+o:""),t&&(n.ref=c);let l=e;return e[0]&&(l=n.as||e,delete n.as),A&&l[0]&&A(n),C(l,n)}return t?t(a):a}}var R=e=>"function"==typeof e,F=(e,t)=>R(e)?e(t):e,q=(()=>{let e=0;return()=>(++e).toString()})(),E=(()=>{let e;return()=>e})(),O=(e,t)=>{switch(t.type){case 0:return{...e,toasts:[t.toast,...e.toasts].slice(0,20)};case 1:return{...e,toasts:e.toasts.map(e=>e.id===t.toast.id?{...e,...t.toast}:e)};case 2:let{toast:s}=t;return O(e,{type:+!!e.toasts.find(e=>e.id===s.id),toast:s});case 3:let{toastId:r}=t;return{...e,toasts:e.toasts.map(e=>e.id===r||void 0===r?{...e,dismissed:!0,visible:!1}:e)};case 4:return void 0===t.toastId?{...e,toasts:[]}:{...e,toasts:e.toasts.filter(e=>e.id!==t.toastId)};case 5:return{...e,pausedAt:t.time};case 6:let a=t.time-(e.pausedAt||0);return{...e,pausedAt:void 0,toasts:e.toasts.map(e=>({...e,pauseDuration:e.pauseDuration+a}))}}},$=[],I={toasts:[],pausedAt:void 0},M=e=>{I=O(I,e),$.forEach(e=>{e(I)})},T={blank:4e3,error:4e3,success:2e3,loading:1/0,custom:4e3},L=(e={})=>{let[t,s]=j(I),r=Q(I);H(()=>(r.current!==I&&s(I),$.push(s),()=>{let e=$.indexOf(s);e>-1&&$.splice(e,1)}),[]);let a=t.toasts.map(t=>{var s,r,a;return{...e,...e[t.type],...t,removeDelay:t.removeDelay||(null==(s=e[t.type])?void 0:s.removeDelay)||(null==e?void 0:e.removeDelay),duration:t.duration||(null==(r=e[t.type])?void 0:r.duration)||(null==e?void 0:e.duration)||T[t.type],style:{...e.style,...null==(a=e[t.type])?void 0:a.style,...t.style}}});return{...t,toasts:a}},D=(e,t="blank",s)=>({createdAt:Date.now(),visible:!0,dismissed:!1,type:t,ariaProps:{role:"status","aria-live":"polite"},message:e,pauseDuration:0,...s,id:(null==s?void 0:s.id)||q()}),B=e=>(t,s)=>{let r=D(t,e,s);return M({type:2,toast:r}),r.id},G=(e,t)=>B("blank")(e,t);G.error=B("error"),G.success=B("success"),G.loading=B("loading"),G.custom=B("custom"),G.dismiss=e=>{M({type:3,toastId:e})},G.remove=e=>M({type:4,toastId:e}),G.promise=(e,t,s)=>{let r=G.loading(t.loading,{...s,...null==s?void 0:s.loading});return"function"==typeof e&&(e=e()),e.then(e=>{let a=t.success?F(t.success,e):void 0;return a?G.success(a,{id:r,...s,...null==s?void 0:s.success}):G.dismiss(r),e}).catch(e=>{let a=t.error?F(t.error,e):void 0;a?G.error(a,{id:r,...s,...null==s?void 0:s.error}):G.dismiss(r)}),e};var U=(e,t)=>{M({type:1,toast:{id:e,height:t}})},K=()=>{M({type:5,time:Date.now()})},Y=new Map,J=1e3,Z=(e,t=J)=>{if(Y.has(e))return;let s=setTimeout(()=>{Y.delete(e),M({type:4,toastId:e})},t);Y.set(e,s)},V=z`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
 transform: scale(1) rotate(45deg);
  opacity: 1;
}`,W=z`
from {
  transform: scale(0);
  opacity: 0;
}
to {
  transform: scale(1);
  opacity: 1;
}`,X=z`
from {
  transform: scale(0) rotate(90deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(90deg);
	opacity: 1;
}`,ee=(P("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#ff4b4b"};
  position: relative;
  transform: rotate(45deg);

  animation: ${V} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;

  &:after,
  &:before {
    content: '';
    animation: ${W} 0.15s ease-out forwards;
    animation-delay: 150ms;
    position: absolute;
    border-radius: 3px;
    opacity: 0;
    background: ${e=>e.secondary||"#fff"};
    bottom: 9px;
    left: 4px;
    height: 2px;
    width: 12px;
  }

  &:before {
    animation: ${X} 0.15s ease-out forwards;
    animation-delay: 180ms;
    transform: rotate(90deg);
  }
`,z`
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
`),et=(P("div")`
  width: 12px;
  height: 12px;
  box-sizing: border-box;
  border: 2px solid;
  border-radius: 100%;
  border-color: ${e=>e.secondary||"#e0e0e0"};
  border-right-color: ${e=>e.primary||"#616161"};
  animation: ${ee} 1s linear infinite;
`,z`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(45deg);
	opacity: 1;
}`),es=z`
0% {
	height: 0;
	width: 0;
	opacity: 0;
}
40% {
  height: 0;
	width: 6px;
	opacity: 1;
}
100% {
  opacity: 1;
  height: 10px;
}`,er=(P("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#61d345"};
  position: relative;
  transform: rotate(45deg);

  animation: ${et} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;
  &:after {
    content: '';
    box-sizing: border-box;
    animation: ${es} 0.2s ease-out forwards;
    opacity: 0;
    animation-delay: 200ms;
    position: absolute;
    border-right: 2px solid;
    border-bottom: 2px solid;
    border-color: ${e=>e.secondary||"#fff"};
    bottom: 6px;
    left: 6px;
    height: 10px;
    width: 6px;
  }
`,P("div")`
  position: absolute;
`,P("div")`
  position: relative;
  display: flex;
  justify-content: center;
  align-items: center;
  min-width: 20px;
  min-height: 20px;
`,z`
from {
  transform: scale(0.6);
  opacity: 0.4;
}
to {
  transform: scale(1);
  opacity: 1;
}`);P("div")`
  position: relative;
  transform: scale(0.6);
  opacity: 0.4;
  min-width: 20px;
  animation: ${er} 0.3s 0.12s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
`,P("div")`
  display: flex;
  align-items: center;
  background: #fff;
  color: #363636;
  line-height: 1.3;
  will-change: transform;
  box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1), 0 3px 3px rgba(0, 0, 0, 0.05);
  max-width: 350px;
  pointer-events: auto;
  padding: 8px 10px;
  border-radius: 8px;
`,P("div")`
  display: flex;
  justify-content: center;
  margin: 4px 10px;
  color: inherit;
  flex: 1 1 auto;
  white-space: pre-line;
`,r=h.createElement,g.p=void 0,C=r,k=void 0,A=void 0,S`
  z-index: 9999;
  > * {
    pointer-events: auto;
  }
`;let ea=()=>{let[e,t]=(0,h.useState)({name:"",email:"",phone:"",subject:"",message:"",source_enquiry:"alivaa-gurugram-contact-us",web_source:"alivaahotels.com"}),[s,r]=(0,h.useState)(!1),[i,n]=(0,h.useState)(""),[m,p]=(0,h.useState)({}),b=()=>{let t={};return e.name.trim()?e.name.trim().length<2&&(t.name="Name must be at least 2 characters"):t.name="Name is required",e.email.trim()?/^\S+@\S+\.\S+$/.test(e.email)||(t.email="Email is invalid"):t.email="Email is required",e.phone.trim()?/^\d{10,}$/.test(e.phone.trim())||(t.phone="Phone must be at least 10 digits and contain digits only"):t.phone="Phone is required",e.subject.trim()?e.subject.trim().length<3&&(t.subject="Subject must be at least 3 characters"):t.subject="Subject is required",e.message.trim()?e.message.trim().length<5&&(t.message="Message must be at least 5 characters"):t.message="Message is required",p(t),0===Object.keys(t).length},f=e=>{let{name:s,value:r}=e.target;t(e=>({...e,[s]:r})),m[s]&&p(e=>{let t={...e};return delete t[s],t})},x=async s=>{if(s.preventDefault(),!b())return void G.error("Please fix the errors in the form.");r(!0),n("");try{let s=await fetch("https://demo.cinuniverse.com/alivaa/contact-mail.php",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(e)}),r=await s.json();"success"===r.status?(G.success(r.message||"Form submitted successfully!"),n(r.message||"Form submitted successfully!"),t({name:"",email:"",phone:"",subject:"",message:"",source_enquiry:"alivaa-gurugram-contact-us",web_source:"alivaahotels.com"}),p({})):(G.error(r.message||"Submission failed!"),n(r.message||"Submission failed!"))}catch(e){G.error("Something went wrong. Please try again."),n("Something went wrong. Please try again.")}finally{r(!1),setTimeout(()=>n(""),8e3)}};return(0,a.jsx)("section",{className:"contact-us-2  contact-us-main",children:(0,a.jsxs)("div",{className:"jsx-ebcb2ccc070fd0ac container contact-us-main-form",children:[(0,a.jsx)("div",{className:"jsx-ebcb2ccc070fd0ac row justify-content-center",children:(0,a.jsx)("div",{className:"jsx-ebcb2ccc070fd0ac col-md-12",children:(0,a.jsxs)("form",{onSubmit:x,noValidate:!0,className:"jsx-ebcb2ccc070fd0ac Query-form-fields",children:[(0,a.jsx)("div",{className:"jsx-ebcb2ccc070fd0ac col-xs-12 no-pad",children:(0,a.jsxs)("div",{className:"jsx-ebcb2ccc070fd0ac row",children:[(0,a.jsx)("div",{className:"jsx-ebcb2ccc070fd0ac col-lg-6 col-md-6 col-xs-12",children:(0,a.jsxs)("div",{className:"jsx-ebcb2ccc070fd0ac form-group mb-3",children:[(0,a.jsx)("input",{type:"text",name:"name",maxLength:30,placeholder:"Name",required:!0,value:e.name,onChange:f,className:`jsx-ebcb2ccc070fd0ac w-full p-2 border form-control ${m.name?"is-invalid":""}`}),m.name&&(0,a.jsx)("small",{className:"jsx-ebcb2ccc070fd0ac text-danger",children:m.name})]})}),(0,a.jsx)("div",{className:"jsx-ebcb2ccc070fd0ac col-lg-6 col-md-6 col-xs-12",children:(0,a.jsxs)("div",{className:"jsx-ebcb2ccc070fd0ac form-group mb-3",children:[(0,a.jsx)("input",{type:"email",name:"email",placeholder:"Email",maxLength:100,required:!0,value:e.email,onChange:f,className:`jsx-ebcb2ccc070fd0ac w-full p-2 border form-control ${m.email?"is-invalid":""}`}),m.email&&(0,a.jsx)("small",{className:"jsx-ebcb2ccc070fd0ac text-danger",children:m.email})]})})]})}),(0,a.jsx)("div",{className:"jsx-ebcb2ccc070fd0ac col-xs-12 no-pad ",children:(0,a.jsxs)("div",{className:"jsx-ebcb2ccc070fd0ac row",children:[(0,a.jsx)("div",{className:"jsx-ebcb2ccc070fd0ac col-lg-6 col-md-6 col-xs-12",children:(0,a.jsxs)("div",{className:"jsx-ebcb2ccc070fd0ac form-group mb-3",children:[(0,a.jsx)("input",{type:"tel",maxLength:10,name:"phone",placeholder:"Phone",required:!0,value:e.phone,onChange:f,className:`jsx-ebcb2ccc070fd0ac w-full p-2 border form-control ${m.phone?"is-invalid":""}`}),m.phone&&(0,a.jsx)("small",{className:"jsx-ebcb2ccc070fd0ac text-danger",children:m.phone})]})}),(0,a.jsx)("div",{className:"jsx-ebcb2ccc070fd0ac col-lg-6 col-md-6 col-xs-12",children:(0,a.jsxs)("div",{className:"jsx-ebcb2ccc070fd0ac form-group mb-3",children:[(0,a.jsx)("input",{type:"text",name:"subject",max:50,placeholder:"Subject",required:!0,value:e.subject,onChange:f,className:`jsx-ebcb2ccc070fd0ac w-full p-2 border form-control ${m.subject?"is-invalid":""}`}),m.subject&&(0,a.jsx)("small",{className:"jsx-ebcb2ccc070fd0ac text-danger",children:m.subject})]})})]})}),(0,a.jsx)("div",{className:"jsx-ebcb2ccc070fd0ac col-xs-12 no-pad ",children:(0,a.jsx)("div",{className:"jsx-ebcb2ccc070fd0ac row",children:(0,a.jsx)("div",{className:"jsx-ebcb2ccc070fd0ac col-lg-12 col-md-12 col-xs-12",children:(0,a.jsxs)("div",{className:"jsx-ebcb2ccc070fd0ac form-group mb-3",children:[(0,a.jsx)("textarea",{name:"message",placeholder:"Message",maxLength:500,required:!0,value:e.message,onChange:f,className:`jsx-ebcb2ccc070fd0ac w-full p-2 border form-control ${m.message?"is-invalid":""}`}),m.message&&(0,a.jsx)("small",{className:"jsx-ebcb2ccc070fd0ac text-danger",children:m.message})]})})})}),(0,a.jsx)("div",{className:"jsx-ebcb2ccc070fd0ac col-xs-12 no-pad",children:(0,a.jsx)("div",{className:"jsx-ebcb2ccc070fd0ac row",children:(0,a.jsxs)("div",{className:"jsx-ebcb2ccc070fd0ac col-lg-12 col-md-12 col-xs-12 voffset-bottom2",children:[(0,a.jsx)("div",{className:"jsx-ebcb2ccc070fd0ac form-group mb-3 text-center",children:(0,a.jsx)("button",{type:"submit",disabled:s,className:"jsx-ebcb2ccc070fd0ac btn btn-primary contact-submit mt-3",children:s?"Processing...":"Submit"})}),(0,a.jsx)("div",{className:"jsx-ebcb2ccc070fd0ac",children:i&&(0,a.jsx)("p",{style:{color:(i.toLowerCase().includes("success"),"green"),fontWeight:"bold"},className:"jsx-ebcb2ccc070fd0ac btn",children:i})})]})})})]})})}),(0,a.jsx)(c(),{id:"ebcb2ccc070fd0ac",children:"input.jsx-ebcb2ccc070fd0ac,textarea.jsx-ebcb2ccc070fd0ac{border:1px solid#ddd;-webkit-border-radius:0px;-moz-border-radius:0px;border-radius:0px}input.jsx-ebcb2ccc070fd0ac:focus,textarea.jsx-ebcb2ccc070fd0ac:focus{-webkit-box-shadow:none;-moz-box-shadow:none;box-shadow:none}.contact-submit.jsx-ebcb2ccc070fd0ac{letter-spacing:2px;font-size:14px;font-weight:600;padding:7px 20px;text-transform:uppercase;-webkit-border-radius:0px;-moz-border-radius:0px;border-radius:0px}.box-d-flex.jsx-ebcb2ccc070fd0ac{display:-webkit-box;display:-webkit-flex;display:-moz-box;display:-ms-flexbox;display:flex;gap:10px}.address-contact.jsx-ebcb2ccc070fd0ac{-webkit-box-shadow:rgba(149,157,165,.2)0px 8px 24px;-moz-box-shadow:rgba(149,157,165,.2)0px 8px 24px;box-shadow:rgba(149,157,165,.2)0px 8px 24px;padding:1.5rem 1rem;margin-bottom:.5rem}.address-contact.jsx-ebcb2ccc070fd0ac .box-d-flex.jsx-ebcb2ccc070fd0ac p.jsx-ebcb2ccc070fd0ac{margin-bottom:0}.map-iframe.jsx-ebcb2ccc070fd0ac{-webkit-filter:grayscale(1)opacity(.9);filter:grayscale(1)opacity(.9)}.inner-head-title.jsx-ebcb2ccc070fd0ac{font-size:20px}"}),(0,a.jsxs)("div",{className:"jsx-ebcb2ccc070fd0ac row mb-3 mt-4",children:[(0,a.jsx)("div",{className:"jsx-ebcb2ccc070fd0ac col-lg-6 col-md-6",children:(0,a.jsxs)("div",{className:"jsx-ebcb2ccc070fd0ac location-address-contact",children:[(0,a.jsxs)("div",{className:"jsx-ebcb2ccc070fd0ac address-contact",children:[(0,a.jsx)("h3",{className:"jsx-ebcb2ccc070fd0ac inner-head-title",children:"Address"}),(0,a.jsxs)("div",{className:"jsx-ebcb2ccc070fd0ac box-d-flex",children:[(0,a.jsx)(o,{}),(0,a.jsx)("p",{className:"jsx-ebcb2ccc070fd0ac",children:(0,a.jsx)(u(),{href:"https://maps.app.goo.gl/tAZTrh2Hvv7YhEBE8",target:"_blank",children:" Kausalya Park, Block L1, Padmini Enclave, Hauz Khas, New Delhi, Delhi 110016"})})]})]}),(0,a.jsxs)("div",{className:"jsx-ebcb2ccc070fd0ac address-contact",children:[(0,a.jsx)("h3",{className:"jsx-ebcb2ccc070fd0ac inner-head-title",children:"Phone"}),(0,a.jsxs)("div",{className:"jsx-ebcb2ccc070fd0ac box-d-flex",children:[(0,a.jsx)(l,{}),(0,a.jsx)("p",{className:"jsx-ebcb2ccc070fd0ac",children:(0,a.jsx)(u(),{href:"tel:01140752200",children:"011 4075 2200"})})]})]}),(0,a.jsxs)("div",{className:"jsx-ebcb2ccc070fd0ac address-contact",children:[(0,a.jsx)("h3",{className:"jsx-ebcb2ccc070fd0ac inner-head-title",children:"Email"}),(0,a.jsxs)("div",{className:"jsx-ebcb2ccc070fd0ac box-d-flex",children:[(0,a.jsx)(d,{}),(0,a.jsx)("p",{className:"jsx-ebcb2ccc070fd0ac",children:(0,a.jsx)(u(),{href:"maito:reservations@amritara.co.in",children:"reservations@amritara.co.in"})})]})]})]})}),(0,a.jsx)("div",{className:"jsx-ebcb2ccc070fd0ac col-lg-6 col-md-6",children:(0,a.jsx)("div",{className:"jsx-ebcb2ccc070fd0ac row",children:(0,a.jsx)("iframe",{src:"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3504.796479986025!2d77.20158805421443!3d28.545836415441816!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390d1bf8e2340a6f%3A0x2bb9cba86c44b4e1!2sAmritara%20Hotels%20%26%20Resorts%20Pvt.%20Ltd.!5e0!3m2!1sen!2sin!4v1750839896235!5m2!1sen!2sin",width:"100%",height:"350",className:"jsx-ebcb2ccc070fd0ac map-iframe"})})})]})]})})}},8550:(e,t,s)=>{"use strict";s.r(t),s.d(t,{default:()=>d,metadata:()=>l});var r=s(7413);s(3384);var a=s(4536),i=s.n(a);s(6407);var c=s(4031),n=s(3702),o=s(2655);let l={title:"Hotels and Resorts in India - Amritara Hotels",description:"Amritara Hotels- A group of hotels with the best luxury and heritage hotels and resorts in India. Stay in the best accommodations with all the contemporary amenities. Book now.",alternates:{canonical:"/contact-us"}};function d(){return(0,r.jsxs)(r.Fragment,{children:[(0,r.jsx)(c.default,{}),(0,r.jsxs)("section",{className:"hero-section-inner",children:[(0,r.jsxs)("video",{autoPlay:!0,loop:!0,muted:!0,playsInline:!0,className:"w-100 inner-hero-image",thumbnail:"/img/banner-thumbnail.png",poster:"/img/banner-thumbnail.png",children:[(0,r.jsx)("source",{src:"/img/amritara-new-banner-video.mp4",type:"video/mp4"}),"Your browser does not support the video tag."]}),(0,r.jsx)("div",{className:"inner-hero-content",children:(0,r.jsxs)("div",{className:"text-center",children:[(0,r.jsx)("h2",{className:"inner-banner-heading",children:"Contact Us"}),(0,r.jsx)("nav",{"aria-label":"breadcrumb",className:"banner-breadcrumb",children:(0,r.jsxs)("ol",{className:"breadcrumb",children:[(0,r.jsxs)("li",{className:"breadcrumb-item",children:[(0,r.jsx)(i(),{href:"/",children:"Home"}),(0,r.jsx)(n.A,{})]}),(0,r.jsx)("li",{className:"breadcrumb-item active","aria-current":"page",children:"Contact Us"})]})})]})})]}),(0,r.jsxs)("section",{className:"about-us-page section-padding",children:[(0,r.jsx)("div",{className:"container",children:(0,r.jsxs)("div",{className:"heading-style-1",children:[(0,r.jsx)("h1",{className:"mb-4 text-center global-heading",children:"Amritara Hotels & Resorts"}),(0,r.jsx)("span",{className:"line-1"}),(0,r.jsx)("span",{className:"line-2"})]})}),(0,r.jsx)(o.default,{})]})]})}},8813:(e,t,s)=>{"use strict";s.r(t),s.d(t,{default:()=>d});var r=s(687);s(6022);var a=s(5814),i=s.n(a),c=s(474),n=s(3210),o=s(6785),l=s(1860);let d=()=>{let[e,t]=(0,n.useState)(!1),[s,a]=(0,n.useState)(!1);(0,n.useEffect)(()=>{let e=()=>{window.scrollY>50?t(!0):t(!1)};return window.addEventListener("scroll",e),()=>{window.removeEventListener("scroll",e)}},[]);let d=()=>{a(!s)};return(0,r.jsx)(r.Fragment,{children:(0,r.jsxs)("header",{className:"header-section",children:[(0,r.jsx)("nav",{className:`navbar navbar-expand-lg navbar-light ${e?"scrolled":""}`,children:(0,r.jsx)("div",{className:"container",children:(0,r.jsxs)("div",{className:"header-display-flex",children:[(0,r.jsx)(i(),{className:"navbar-brand",href:"/",children:(0,r.jsx)(c.default,{src:"/img/logo.png",className:"header-logo",alt:"Amritara Hotels And Resorts",width:300,height:200})}),(0,r.jsx)("div",{className:"navbarnav",id:"navbarNav",children:(0,r.jsxs)("div",{className:"display-flex",children:[(0,r.jsx)(i(),{className:"me-3 header-btnn-top login-menu-header",href:"/",children:"Login/Join"}),(0,r.jsx)(i(),{className:"me-3 header-btnn-top book-menu-header",href:"/",children:"Book Now"}),(0,r.jsx)("button",{onClick:d,className:"sidebar-toggle border-0 bg-transparent ms-3",children:(0,r.jsx)(o.A,{size:20,className:"toggle-image-s"})})]})})]})})}),(0,r.jsxs)("div",{className:`sidebar-menu ${s?"open":""}`,children:[(0,r.jsx)("div",{className:"sidebar-header",children:(0,r.jsx)("button",{onClick:d,className:"close-btn",children:(0,r.jsx)(l.A,{color:"black",size:24})})}),(0,r.jsx)("div",{className:"sidebar-content",children:(0,r.jsxs)("ul",{className:"sidebar-nav",children:[(0,r.jsx)("li",{children:(0,r.jsx)(i(),{href:"/",onClick:d,children:"Home"})}),(0,r.jsx)("li",{children:(0,r.jsx)(i(),{href:"/our-hotels",onClick:d,children:"Our Hotels"})}),(0,r.jsx)("li",{children:(0,r.jsx)(i(),{href:"/our-offers",onClick:d,children:"Our Offers"})}),(0,r.jsx)("li",{children:(0,r.jsx)(i(),{href:"/about-us",onClick:d,children:"About Us"})}),(0,r.jsx)("li",{children:(0,r.jsx)(i(),{href:"/offers",onClick:d,children:"Rewards"})}),(0,r.jsx)("li",{children:(0,r.jsx)(i(),{href:"/contact-us",onClick:d,children:"Contact Us"})})]})})]})]})})}},9121:e=>{"use strict";e.exports=require("next/dist/server/app-render/action-async-storage.external.js")},9294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},9551:e=>{"use strict";e.exports=require("url")}};var t=require("../../webpack-runtime.js");t.C(e);var s=e=>t(t.s=e),r=t.X(0,[447,552,718,187],()=>s(7152));module.exports=r})();